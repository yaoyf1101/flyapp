
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Question;
import bean.User;
import dao.QuestionDAO;
import dao.UserDAO;

public class QuestionAddServlet extends HttpServlet {

	/**
	 * 添加题目
	 */
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		Question question = new Question();
		question.setTitle(request.getParameter("title"));
		question.setType(request.getParameter("type"));
		question.setA(request.getParameter("A"));
		question.setB(request.getParameter("B"));
		question.setC(request.getParameter("C"));
		question.setD(request.getParameter("D"));
		question.setT(request.getParameter("T"));
		question.setF(request.getParameter("F"));
		question.setScore(request.getParameter("score"));
		question.setAnswer(request.getParameter("answer"));
		question.setAnalysis(request.getParameter("analysis"));
		new QuestionDAO().add(question);
		response.sendRedirect("/flyapp/listQuestion");
	}
}