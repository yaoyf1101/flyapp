
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.UserDAO;

public class UserLoginServlet extends HttpServlet {

	/**
	 * 用户登录验证
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String name = request.getParameter("name");
		String password = request.getParameter("password");
		int type = Integer.parseInt(request.getParameter("type"));

		int result = 0;
		if (new UserDAO().isLogin(name, password, type)) {
			if (type == 0) {
				result = 1;
			}
			if (type == 1) {
				result = 2;
			}
		} else {
			result = -1;
		}
		PrintWriter pw = response.getWriter();
		pw.println(result);
	}
}