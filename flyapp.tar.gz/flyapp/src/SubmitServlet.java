  

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Question;
import net.sf.json.*;

  
public class SubmitServlet extends HttpServlet {  
    protected void service(HttpServletRequest request, HttpServletResponse response)  
            throws ServletException, IOException {
    	String data =request.getParameter("data");
        
        System.out.println("服务端接收到的数据是：" +data);
  
        JSONObject json=JSONObject.fromObject(data); 
          
        System.out.println("转换为JSON对象之后是："+ json);
           
        Question question = (Question)JSONObject.toBean(json,Question.class); 
        System.out.println("转换为question对象之后是："+question);
    }  
}  