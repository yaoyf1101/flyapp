
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Question;
import dao.QuestionDAO;
import net.sf.json.JSONSerializer;

public class QuestionListServlet extends HttpServlet {

	/**
	 * 获取题目列表
	 */
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");

		List<Question> questions = new QuestionDAO().list();
		StringBuffer sb = new StringBuffer();
		sb.append("<table align='left' border='1' cellspacing='0'>\r\n");
		sb.append("<tr><td>id</td><td>题目</td><td>题目类型</td><td>A选项</td><td>B选项</td><td>C选项</td><td>D选项</td><td>T选项</td><td>F选项</td><td>分值</td><td>正确答案</td><td>答案解析</td><td>edit</td><td>delete</td></tr>\r\n");
		String trFormat = "<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td><a href='editQuestion?id=%s'>edit</a></td><td><a href='deleteQuestion?id=%s'>delete</a></td></tr>\r\n";

		for (Question question : questions) {
			String tr = String.format(trFormat, question.getId(), question.getTitle(), question.getType(),
					question.getA(),question.getB(),question.getC(),question.getD(),question.getT(),question.getF(),
					question.getScore(),question.getAnswer(),question.getAnalysis(), question.getId(), question.getId());
			sb.append(tr);
		}
		sb.append("</table>");
		String result = JSONSerializer.toJSON(questions).toString();
		System.out.println("服务端返回的数据是：" + result);
		response.getWriter().write(sb.toString());
	}
}