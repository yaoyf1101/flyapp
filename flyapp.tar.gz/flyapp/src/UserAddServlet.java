
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.UserDAO;

public class UserAddServlet extends HttpServlet {

	/**
	 * 用户注册功能实现
	 */
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");

		User user = new User();
		user.setName(request.getParameter("name"));
		user.setPassword(request.getParameter("password"));
		user.setType(Integer.parseInt(request.getParameter("type")));

		if (new UserDAO().isNotHave(request.getParameter("name"))) {
			new UserDAO().add(user);
			PrintWriter pw = response.getWriter();
			pw.println("1");
		} else {
			PrintWriter pw = response.getWriter();
			pw.println("-1");
		}
		// response.sendRedirect("/flyapp/listUser");
	}
}