
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.UserDAO;

public class UserEditServlet extends HttpServlet {

	/**
	 * 修改用户信息，目前仅支持修改密码
	 */
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		User user = new UserDAO().get(id);
		StringBuffer format = new StringBuffer();
		response.setContentType("text/html; charset=UTF-8");
		format.append("<!DOCTYPE html>");
		format.append("<form action='updateUser' method='post'>");
		format.append("名字 ： <input type='text' name='name' value='%s' > <br>");
		format.append("密码 ： <input type='text' name='password'  value='%s' > <br>");
		format.append("用户类型： <input type='text' name='type'  value='%d' > <br>");
		format.append("<input type='hidden' name='id' value='%d'>");
		format.append("<input type='submit' value='更新'>");
		format.append("</form>");
		String html = String.format(format.toString(), user.getName(), user.getPassword(), user.getType(),
				user.getId());
		response.getWriter().write(html);
	}
}