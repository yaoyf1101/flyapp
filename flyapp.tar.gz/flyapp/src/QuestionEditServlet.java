
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Question;
import bean.User;
import dao.QuestionDAO;
import dao.UserDAO;

public class QuestionEditServlet extends HttpServlet {

	/**
	 * 修改题目信息
	 */
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		Question question = new QuestionDAO().get(id);
		StringBuffer format = new StringBuffer();
		response.setContentType("text/html; charset=UTF-8");
		format.append("<!DOCTYPE html>");
		format.append("<form action='updateQuestion' method='post'>");
		format.append("ID:<input type='text' name='id' value='%d'>");
		format.append("题目 ： <input type='text' name='title' value='%s' > <br>");
		format.append("题目类型 ： <input type='text' name='type'  value='%s' > <br>");
		format.append("A选项： <input type='text' name='A'  value='%s' > <br>");
		format.append("B选项： <input type='text' name='B'  value='%s' > <br>");
		format.append("C选项： <input type='text' name='C'  value='%s' > <br>");
		format.append("D选项： <input type='text' name='D'  value='%s' > <br>");
		format.append("T选项： <input type='text' name='T'  value='%s' > <br>");
		format.append("F选项： <input type='text' name='F'  value='%s' > <br>");
		format.append("分值： <input type='text' name='score'  value='%s' > <br>");
		format.append("正确答案： <input type='text' name='answer'  value='%s' > <br>");
		format.append("答案解析： <input type='text' name='analysis'  value='%s' > <br>");
		format.append("<input type='submit' value='更新'>");
		format.append("</form>");
		String html = String.format(format.toString(), question.getId(),question.getTitle(), question.getType(), question.getA(),
				question.getB(),question.getC(),question.getD(),question.getT(),question.getF(),
				question.getScore(),question.getAnswer(),question.getAnalysis()	);
		response.getWriter().write(html);
	}
}