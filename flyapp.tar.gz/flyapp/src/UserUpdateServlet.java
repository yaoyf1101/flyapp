
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.UserDAO;

public class UserUpdateServlet extends HttpServlet {

	/**
	 * 修改密码
	 */
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int userid = 0;
		request.setCharacterEncoding("UTF-8");
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		int type = Integer.parseInt(request.getParameter("type"));
		if (new UserDAO().isNotHave(name)) {
			//if user is not exist return -1
			PrintWriter pw = response.getWriter();
			pw.println("-1");
		} else {
			// get user id
			userid = new UserDAO().getId(name);
			// update user password
			User user = new UserDAO().get(userid);
			user.setPassword(password);
			if (user.getType() != type) {
			// if user want to modify type stop! 
				PrintWriter pw = response.getWriter();
				pw.println("0");
				return;
			}
			new UserDAO().update(user);
			PrintWriter pw = response.getWriter();
			pw.println("1");
		}
	}
}