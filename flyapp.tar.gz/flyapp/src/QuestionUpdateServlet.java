
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Question;
import bean.User;
import dao.QuestionDAO;
import dao.UserDAO;

public class QuestionUpdateServlet extends HttpServlet {

	/**
	 * 编辑题目
	 */
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		request.setCharacterEncoding("UTF-8");
		int id = Integer.parseInt(request.getParameter("id"));
		String title = request.getParameter("title");
		String type = request.getParameter("type");
		String A = request.getParameter("A");
		String B = request.getParameter("B");
		String C = request.getParameter("C");
		String D = request.getParameter("D");
		String T = request.getParameter("T");
		String F = request.getParameter("F");
		String score = request.getParameter("score");
		String answer = request.getParameter("answer");
		String analysis = request.getParameter("analysis");
		Question question = new QuestionDAO().get(id);
		question.setId(id);
		question.setTitle(title);		
		question.setType(type);
		question.setA(A);
		question.setB(B);
		question.setC(C);
		question.setD(D);	
		question.setT(T);
		question.setF(F);
		question.setScore(score);
		question.setAnswer(answer);
		question.setAnalysis(analysis);
		new QuestionDAO().update(question);
		response.sendRedirect("/flyapp/listQuestion");
	}
}
