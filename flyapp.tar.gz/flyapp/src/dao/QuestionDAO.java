package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.Question;

public class QuestionDAO {
	public QuestionDAO() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public Connection getConnection() throws SQLException {
		return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/flyapp?characterEncoding=UTF-8", "root",
				"111111");
	}

	// 获取题库题目总数
	public int getTotal() {
		int total = 0;
		try (Connection c = getConnection(); Statement s = c.createStatement();) {
			String sql = "select count(*) from question";
			ResultSet rs = s.executeQuery(sql);
			while (rs.next()) {
				total = rs.getInt(1);
			}
			System.out.println("total:" + total);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return total;
	}

	// 添加题目
	public void add(Question question) {
		String sql = "insert into question values(null,?,?,?,?,?,?,?,?,?,?,?)";
		try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			/*
			 * 添加除ID以外的具体的数据
			 */
			ps.setString(1, question.getTitle());
			ps.setString(2, question.getType());
			ps.setString(3, question.getA());
			ps.setString(4, question.getB());
			ps.setString(5, question.getC());
			ps.setString(6, question.getD());
			ps.setString(7, question.getT());
			ps.setString(8, question.getF());
			ps.setString(9, question.getScore());
			ps.setString(10, question.getAnswer());
			ps.setString(11, question.getAnalysis());
			ps.execute();
			ResultSet rs = ps.getGeneratedKeys();
			if (rs.next()) {
				int id = rs.getInt(1);
				question.setId(id);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 编辑题目
	public void update(Question question) {
		String sql = "update question set title= ?, type = ?,option_a = ?, option_b = ?, option_c = ?, option_d = ?, option_t = ?, option_f = ?, score = ?, answer = ?, analysis = ? where id = ?";
		try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			/*
			 * 修改具体的数据
			 */
			ps.setString(1,question.getTitle());
			ps.setString(2,question.getType());
			ps.setString(3,question.getA());
			ps.setString(4,question.getB());
			ps.setString(5,question.getC());
			ps.setString(6,question.getD());
			ps.setString(7,question.getT());	
			ps.setString(8,question.getF());
			ps.setString(9,question.getScore());
			ps.setString(10,question.getAnswer());
			ps.setString(11,question.getAnalysis());
			ps.setInt(12,question.getId());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// 删除题目
	public void delete(int id) {
		try (Connection c = getConnection(); Statement s = c.createStatement();) {
			String sql = "delete from question where id = " + id;
			s.execute(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public Question get(int id) {
		Question question = null;
		try (Connection c = getConnection(); Statement s = c.createStatement();) {
			String sql = "select * from question where id = " + id;
			ResultSet rs = s.executeQuery(sql);
			if (rs.next()) {
				question = new Question();
				// 获取题目数据并包装给这个题目对象，最终返回这个对象
				// 获取题目数据
				String title = rs.getString(2);
				String type = rs.getString(3);
				String A = rs.getString(4);
				String B = rs.getString(5);
				String C = rs.getString(6);
				String D = rs.getString(7);
				String T = rs.getString(8);
				String F = rs.getString(9);
				String score = rs.getString(10);
				String answer = rs.getString(11);
				String analysis = rs.getString(12);
				// 设置题目数据
				question.setId(id);
				question.setTitle(title);		
				question.setType(type);
				question.setA(A);
				question.setB(B);
				question.setC(C);
				question.setD(D);	
				question.setT(T);
				question.setF(F);
				question.setScore(score);
				question.setAnswer(answer);
				question.setAnalysis(analysis);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return question;
	}

	public List<Question> list() {
		return list(0, Short.MAX_VALUE);
	}

	// 获取所有题目
	public List<Question> list(int start, int count) {
		List<Question> questions = new ArrayList<Question>();
		String sql = "select * from question order by id desc limit ?,? ";
		try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			ps.setInt(1, start);
			ps.setInt(2, count);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				Question question = new Question();
				// 获取题目数据
				int id = rs.getInt(1);
				String title = rs.getString(2);
				String type = rs.getString(3);
				String A = rs.getString(4);
				String B = rs.getString(5);
				String C = rs.getString(6);
				String D = rs.getString(7);
				String T = rs.getString(8);
				String F = rs.getString(9);
				String score = rs.getString(10);
				String answer = rs.getString(11);
				String analysis = rs.getString(12);
				// 设置题目数据
				question.setId(id);
				question.setTitle(title);		
				question.setType(type);
				question.setA(A);
				question.setB(B);
				question.setC(C);
				question.setD(D);	
				question.setT(T);
				question.setF(F);
				question.setScore(score);
				question.setAnswer(answer);
				question.setAnalysis(analysis);
				questions.add(question);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return questions;
	}
}
