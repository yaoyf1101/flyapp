package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import bean.User;

public class UserDAO {

	public UserDAO() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	public Connection getConnection() throws SQLException {
		return DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/flyapp?characterEncoding=UTF-8", "root",
				"111111");
	}

	public int getTotal() {
		int total = 0;
		try (Connection c = getConnection(); Statement s = c.createStatement();) {
			String sql = "select count(*) from user";
			ResultSet rs = s.executeQuery(sql);
			while (rs.next()) {
				total = rs.getInt(1);
			}
			System.out.println("total:" + total);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return total;
	}

	public void add(User user) {
			String sql = "insert into user values(null,?,?,?)";
			try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
				ps.setString(1, user.getName());
				ps.setString(2, user.getPassword());
				ps.setInt(3, user.getType());
				ps.execute();
				ResultSet rs = ps.getGeneratedKeys();
				if (rs.next()) {
					int id = rs.getInt(1);
					user.setId(id);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}	
	}

	public void update(User user) {
		String sql = "update user set name= ?, password = ? , type = ? where id = ?";
		try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			ps.setString(1, user.getName());
			ps.setString(2, user.getPassword());
			ps.setInt(3, user.getType());
			ps.setInt(4, user.getId());
			ps.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delete(int id) {
		try (Connection c = getConnection(); Statement s = c.createStatement();) {
			String sql = "delete from user where id = " + id;
			s.execute(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public User get(int id) {
		User user = null;
		try (Connection c = getConnection(); Statement s = c.createStatement();) {

			String sql = "select * from user where id = " + id;

			ResultSet rs = s.executeQuery(sql);

			if (rs.next()) {
				user = new User();
				String name = rs.getString(2);
				String password = rs.getString("password");
				int type = rs.getInt(4);
				user.setName(name);
				user.setPassword(password);
				user.setType(type);
				user.setId(id);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return user;
	}

	public Boolean isNotHave(String name) {
		Boolean ishave = false;
		try (Connection c = getConnection(); Statement s = c.createStatement();) {

			String sql = "select * from user where name = '" + name+"'";

			ResultSet rs = s.executeQuery(sql);
			if (!rs.next()) {
				ishave = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ishave;
	}
	
	public Boolean isLogin(String name,String password,int type) {
		Boolean ishave = false;
		try (Connection c = getConnection(); Statement s = c.createStatement();) {

			String sql = "select * from user where name = '" + name
					+ "'and password ='"+ password
					+"'and type = '"+type+"'";

			ResultSet rs = s.executeQuery(sql);
			if (rs.next()) {
				ishave = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return ishave;
	}
	
	public int getId(String name) {
		int id = 0;
		try (Connection c = getConnection(); Statement s = c.createStatement();) {
			String sql = "select * from user where name = '" + name+"'";

			ResultSet rs = s.executeQuery(sql);
			if (rs.next()) {
			id = rs.getInt(1);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	  return id;
	}

	public List<User> list() {
		return list(0, Short.MAX_VALUE);
	}

	public List<User> list(int start, int count) {
		List<User> users = new ArrayList<User>();
		String sql = "select * from user order by id desc limit ?,? ";
		try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql);) {
			ps.setInt(1, start);
			ps.setInt(2, count);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				User user = new User();
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String password = rs.getString("password");
				int type = rs.getInt(4);
				user.setName(name);
				user.setPassword(password);
				user.setType(type);
				user.setId(id);
				users.add(user);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return users;
	}

}