
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Question;
import dao.QuestionDAO;
import net.sf.json.*;

public class GetQuestionServlet extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		List<Question> questions = new QuestionDAO().list();
		String result = JSONSerializer.toJSON(questions).toString();
		System.out.println("服务端返回的数据是：" + result);
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().print(result);
		//InputStream is = request.getInputStream();
		//InputStreamReader isr = new InputStreamReader(is,"utf-8");
		//BufferedReader br = new BufferedReader(isr);
		//String userjson = br.readLine();
		//System.out.println("服务端jieshou的数据是：" + userjson);
	}
}