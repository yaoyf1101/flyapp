
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.UserDAO;

public class UserListServlet extends HttpServlet {

	/**
	 * 获取用户信息
	 */
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html; charset=UTF-8");

		List<User> users = new UserDAO().list();
		StringBuffer sb = new StringBuffer();
		sb.append("<table align='left' border='1' cellspacing='0'>\r\n");
		sb.append("<tr><td>id</td><td>name</td><td>password</td><td>type</td><td>edit</td><td>delete</td></tr>\r\n");
		String trFormat = "<tr><td>%d</td><td>%s</td><td>%s</td><td>%d</td><td><a href='editUser?id=%d'>edit</a></td><td><a href='deleteUser?id=%d'>delete</a></td></tr>\r\n";

		for (User user : users) {
			String tr = String.format(trFormat, user.getId(), user.getName(), user.getPassword(), user.getType(),
					user.getId(), user.getId());
			sb.append(tr);
		}
		sb.append("</table>");

		response.getWriter().write(sb.toString());
	}
}